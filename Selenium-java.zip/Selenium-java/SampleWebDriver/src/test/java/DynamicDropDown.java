import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DynamicDropDown {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
//		driver.get("https://www.spicejet.com/");
//		driver.manage().window().maximize();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("(//input[@class='css-1cwyjr8 r-homxoj r-ubezar r-10paoce r-13qz1uu'])[1]")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//div[contains(text(),'Varanasi')]")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("(//input[@class='css-1cwyjr8 r-homxoj r-ubezar r-10paoce r-13qz1uu'])[1]")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("(//div[contains(text(),'Vijayawada')])[1]")).click();
//		Thread.sleep(2000);
//		driver.quit();
		
		
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#fromCity")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(@class,'hsw_autocomplePopup autoSuggestPlugin')]//input")).sendKeys("South Korea");
		Thread.sleep(2000);
		List<WebElement> list = driver.findElements(By.xpath("//p[@class='font14 appendBottom5 blackText']"));
		

		for(WebElement temp : list) {
			System.out.println(temp.getText());
		}
		
		
		for(int i=0;i<list.size();i++) {
			String text = list.get(i).getText();
			System.out.println(text);
			if(text.contains("South Korea")) {
				list.get(i).click();
				break;
			}
	
	
	}
		driver.quit();
	}

}
