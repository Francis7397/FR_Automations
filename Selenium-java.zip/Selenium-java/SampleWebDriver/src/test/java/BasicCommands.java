import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BasicCommands {
	
	

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().window().maximize();
		String title = driver.getTitle();
        System.out.println(title);
		driver.findElement(By.id("signin_button")).click();
		String title1 = driver.getTitle();
        System.out.println(title1);
        String text = driver.findElement(By.xpath("//label[contains(text(),'Login')]")).getText();
        System.out.println(text);
		driver.findElement(By.id("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("password");
		WebElement checkBox = driver.findElement(By.cssSelector("#user_remember_me"));
		checkBox.click();
		System.out.println(checkBox.isSelected());
		driver.findElement(By.cssSelector(".btn-primary")).click();
		List<WebElement> elementName = driver.findElements(By.cssSelector(".btn-primary"));
		int count = elementName.size();
		System.out.println(count);
		driver.close();
		driver.quit();
		
	}
	@Test
	public void sample() {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().window().maximize();
		String title = driver.getTitle();
        System.out.println(title);
		driver.findElement(By.id("signin_button")).click();
		String title1 = driver.getTitle();
        System.out.println(title1);
        String text = driver.findElement(By.xpath("//label[contains(text(),'Login')]")).getText();
        System.out.println(text);
		driver.findElement(By.id("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("password");
		WebElement checkBox = driver.findElement(By.cssSelector("#user_remember_me"));
		checkBox.click();
		System.out.println(checkBox.isSelected());
		driver.findElement(By.cssSelector(".btn-primary")).click();
		List<WebElement> elementName = driver.findElements(By.cssSelector(".btn-primary"));
		int count = elementName.size();
		System.out.println(count);
		driver.close();
		driver.quit();
		
	}

}
