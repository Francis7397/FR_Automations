import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class KeyBoardAction2 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://the-internet.herokuapp.com/key_presses");
		driver.manage().window().maximize();
		
		
		Actions active = new Actions(driver);
		
		active.sendKeys(Keys.SPACE).perform();
		Thread.sleep(2000);
		
		active.sendKeys(Keys.ENTER).perform();
		Thread.sleep(2000);
		
		driver.quit();

	}

}
