import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragandDrop {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		ChromeDriver driver = new ChromeDriver();

		driver.get("https://selenium08.blogspot.com/2020/01/drag-drop.html");
		driver.manage().window().maximize();

		WebElement element1 = driver.findElement(By.id("draggable"));
		WebElement element2 = driver.findElement(By.id("droppable"));

		Actions drag = new Actions(driver);
		drag.dragAndDrop(element1, element2);
		drag.build().perform();
		Thread.sleep(3000);

		System.out.println("move");

		driver.quit();


	}

}
