import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StaticDropdowns {

	public static void main(String[] args) throws Exception {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://chercher.tech/practice/practice-dropdowns-selenium-webdriver");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement dropdown = driver.findElement(By.xpath("//select[contains(@id,'first')]"));
		Select select = new Select(dropdown);
		
		select.selectByIndex(1);
		Thread.sleep(1000);
		
		select.selectByValue("Microsoft");
		Thread.sleep(1000);
//	
		select.selectByVisibleText("Google");
		Thread.sleep(1000);
//		driver.quit();
//		
		
		
		
		List<WebElement> listElements = select.getOptions();
		
		
			
		
		
		for(WebElement temp : listElements) {
			System.out.println(temp.getText());
		}
		for(WebElement temp : listElements) {
			System.out.println("Clicking on "+temp.getText());
			temp.click();
			Thread.sleep(2000);
		}
		

		
		driver.quit();
		
		
	}

}
