package TestNGClass;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebDriverTest {
	
	@Test
	public void test() {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().window().maximize();
		driver.close();
		driver.quit();
		
	}

}
