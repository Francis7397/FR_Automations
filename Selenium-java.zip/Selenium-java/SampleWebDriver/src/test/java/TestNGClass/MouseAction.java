package TestNGClass;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MouseAction {

	@Test

	public void mouse() {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();

		driver.get("https://selenium08.blogspot.com/2020/01/click-and-hold.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		WebElement element1 = driver.findElement(By.xpath("//li[contains(text(),'B')]"));
		WebElement element2 = driver.findElement(By.xpath("//li[contains(text(),'B')]"));

		Actions box = new Actions(driver);

		box.moveToElement(element1);

		box.clickAndHold();

		box.moveToElement(element2);

		box.build().perform();

		box.release().perform();

		box.contextClick(element1);

		box.doubleClick(element2);

		System.out.println("moved");

		driver.quit();

		;
	}

}
