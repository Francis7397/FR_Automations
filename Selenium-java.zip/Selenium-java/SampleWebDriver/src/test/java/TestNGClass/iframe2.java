package TestNGClass;
import java.time.Duration;

import org.openqa.selenium.By;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class iframe2 {
	
	@Test

	public void frame() {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();

		driver.get("https://www.w3schools.com/html/tryit.asp?filename=tryhtml_iframe_height_width");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		driver.switchTo().frame("iframeResult");
		driver.switchTo().frame(0);

		String text = driver.findElement(By.xpath("//h1[contains(text(),'This page is displayed')]")).getText();
		System.out.println(text);

		driver.switchTo().parentFrame();

		String text1 = driver.findElement(By.xpath("//p[contains(text(),'You can use')]")).getText();
		System.out.println(text1);

		driver.quit();

	}

}
