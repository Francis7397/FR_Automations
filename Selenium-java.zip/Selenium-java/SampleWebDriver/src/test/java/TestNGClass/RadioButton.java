package TestNGClass;
import java.awt.RenderingHints.Key;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RadioButton {
	
	@Test

	public void button(){

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();

		driver.get("http://register.rediff.com/register/register.php?FormName=user_details");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	
		
       
		WebElement radioButton1 = driver.findElement(By.xpath("//input[@value='f']"));
		
		radioButton1.click();
		System.out.println(radioButton1.isSelected());
		
		radioButton1.click();
		System.out.println(radioButton1.isDisplayed());
		driver.quit();

	}

}
