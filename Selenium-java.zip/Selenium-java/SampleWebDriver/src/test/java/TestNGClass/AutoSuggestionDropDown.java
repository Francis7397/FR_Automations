package TestNGClass;
import java.time.Duration;


import org.openqa.selenium.By;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AutoSuggestionDropDown {
	
	@Test

	public void suggestion(){
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://www.goibibo.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	
		driver.findElement(By.xpath("(//p[contains(text(),'Enter city or airport')])[1]")).click();
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("South Korea");
		
		driver.findElement(By.xpath("//span[contains(text(),'Seoul, South Korea')]")).click();
		driver.findElement(By.xpath("//ul[contains(.,'One-way')]")).click();
		
		
		driver.findElement(By.xpath("//p[contains(normalize-space(),'Enter city or airport')]")).click();
	
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("brazil");

		driver.findElement(By.xpath("//span[contains(text(),'Brasilia, Brazil')]")).click();
		driver.quit();

	}

}
