package TestNGClass;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StaticDropdowns {
	
	@Test

	public void dropDowns(){
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://chercher.tech/practice/practice-dropdowns-selenium-webdriver");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	
		WebElement dropdown = driver.findElement(By.xpath("//select[contains(@id,'first')]"));
		Select select = new Select(dropdown);
		
		select.selectByIndex(1);
		
		
		select.selectByValue("Microsoft");
		
//	
		select.selectByVisibleText("Google");
		
//		driver.quit();
//		
		
		
		
		List<WebElement> listElements = select.getOptions();
		
		
			
		
		
		for(WebElement temp : listElements) {
			System.out.println(temp.getText());
		}
		for(WebElement temp : listElements) {
			System.out.println("Clicking on "+temp.getText());
			temp.click();
			
		}
		

		
		driver.quit();
		
		
	}

}
