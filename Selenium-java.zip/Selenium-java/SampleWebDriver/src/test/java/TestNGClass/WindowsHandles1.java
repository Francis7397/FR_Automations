package TestNGClass;
import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WindowsHandles1 {
	
	@Test

	public void windowHandle() {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();

		driver.get("https://www.hyrtutorials.com/p/window-handles-practice.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		String parent = driver.getWindowHandle();
		System.out.println("parent window:" + parent);
		driver.findElement(By.id("newWindowBtn")).click();
		Set<String> handles = driver.getWindowHandles();
		for (String handle : handles) {
			System.out.println(handle);
			if (!handle.equals(parent)) {
				driver.switchTo().window(handle);

				driver.findElement(By.id("firstName")).sendKeys("jennie");
				driver.close();
			}
		}
		driver.switchTo().window(parent);
		driver.findElement(By.id("name")).sendKeys("jennie");
		driver.quit();

	}

}
