package TestNGClass;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class KeyBoardActions {
	
	@Test

	public void keyActions() {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		driver.get("https://www.facebook.com/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		WebElement userName = driver.findElement(By.id("email"));
		
		Actions action = new Actions(driver);
		action.moveToElement(userName)
		.click()
		.keyDown(userName, Keys.SHIFT)
		.sendKeys(userName, "Cheng Xaio")
		.keyUp(userName, Keys.SHIFT)
		.doubleClick(userName)
		.contextClick()
		.build()
		.perform();
		
		driver.quit();
	}

}
