package TestNGClass;
import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class KeyBoardAction2 {
	
	@Test

	public void keyBoard(){
		// TODO Auto-generated method stub
		
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://the-internet.herokuapp.com/key_presses");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		
		Actions active = new Actions(driver);
		
		active.sendKeys(Keys.SPACE).perform();
	
		
		active.sendKeys(Keys.ENTER).perform();
		
		
		driver.quit();

	}

}
