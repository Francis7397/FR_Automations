import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ListWindowHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();

		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		driver.findElement(By.xpath("//a[text()='OrangeHRM, Inc']")).click();

		Set<String> windows = driver.getWindowHandles();
		
		List<String> windowList = new ArrayList(windows);
		
		
		String one = windowList.get(0);
		String two = windowList.get(1);
		
		System.out.println(one);
		System.out.println(two);
		
		driver.switchTo().window(one);
		System.out.println(driver.getTitle());
		
		driver.switchTo().window(two);
		System.out.println(driver.getTitle());
		
		
		for(String window:windowList) {
			String titles = driver.switchTo().window(window).getTitle();
			System.out.println(titles);
		}
		

		for(String window:windowList) {
			String titles = driver.switchTo().window(window).getTitle();
			if(titles.equals("OrangeHRM HR Software | Free & Open Source HR Software | HRMS | HRIS | OrangeHRM")) {
				driver.close();
			}
		}
		
		
		driver.quit();
		

	}

}
