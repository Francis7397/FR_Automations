import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MouseAction {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();

		driver.get("https://selenium08.blogspot.com/2020/01/click-and-hold.html");
		driver.manage().window().maximize();

		WebElement element1 = driver.findElement(By.xpath("//li[contains(text(),'B')]"));
		WebElement element2 = driver.findElement(By.xpath("//li[contains(text(),'B')]"));

		Actions box = new Actions(driver);

		box.moveToElement(element1);
		Thread.sleep(2000);
		box.clickAndHold();
		Thread.sleep(5000);
		box.moveToElement(element2);
		Thread.sleep(2000);

		box.build().perform();

		box.release().perform();
		
		box.contextClick(element1);
		Thread.sleep(3000);
		box.doubleClick(element2);

		Thread.sleep(3000);

		System.out.println("moved");

		driver.quit();

		;
	}

}
