import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AutoSuggestionDropDown {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://www.goibibo.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//p[contains(text(),'Enter city or airport')])[1]")).click();
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("South Korea");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Seoul, South Korea')]")).click();
		driver.findElement(By.xpath("//ul[contains(.,'One-way')]")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(normalize-space(),'Enter city or airport')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("brazil");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Brasilia, Brazil')]")).click();
		driver.quit();

	}

}
