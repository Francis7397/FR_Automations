import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExplicitWait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.co.in/");
		driver.manage().window().maximize();
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		
		driver.findElement(By.name("q")).sendKeys("BTS");
		driver.findElement(By.name("q")).sendKeys(Keys.RETURN);
		
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h3[contains(text(),'BTS - Wikipedia')]")));
		element.click();
		
		//driver.findElement(By.xpath("//h3[contains(text(),'BTS - Wikipedia')]")).click();
		
		driver.quit();


	}

}
