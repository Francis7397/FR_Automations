import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckBox {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://the-internet.herokuapp.com/checkboxes");
		driver.manage().window().maximize();
		
		 WebElement checkBox1 = driver.findElement(By.xpath("(//input[@type='checkbox'])[1]"));
		 checkBox1.click();
		 System.out.println(checkBox1.isSelected());
		 
		 WebElement checkBox2 = driver.findElement(By.xpath("(//input[@type='checkbox'])[2]"));
		 checkBox2.click();
		 Thread.sleep(2000);
		 checkBox2.click();
		 System.out.println(checkBox2.isEnabled());
		 driver.quit();
		 
		 

	}

}
