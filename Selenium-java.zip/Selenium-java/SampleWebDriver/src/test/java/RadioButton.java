import java.awt.RenderingHints.Key;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RadioButton {

	public static void main(String[] args) throws Exception {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();

		driver.get("http://register.rediff.com/register/register.php?FormName=user_details");
		driver.manage().window().maximize();
	
		
        Thread.sleep(1000);
		WebElement radioButton1 = driver.findElement(By.xpath("//input[@value='f']"));
		Thread.sleep(1000);
		radioButton1.click();
		System.out.println(radioButton1.isSelected());
		Thread.sleep(1000);
		radioButton1.click();
		System.out.println(radioButton1.isDisplayed());
		driver.quit();

	}

}
